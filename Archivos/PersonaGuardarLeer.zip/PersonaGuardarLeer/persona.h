// persona.h
// Declaraci�n de la clase persona de prueba
// Autor: El Tigre

#ifndef PERSONA_H
#define PERSONA_H

#include <string>

class Persona {
public:
	// Constructor con par�metros. Si no se construye el objeto con par�metros se usan los valores por default
	// establecidos en la declaraci�n del constructor
	Persona(std::string n = " ", short int e = 0, std::string c = " ") : nombre(n), edad(e), cedula(c) {}

	// Constructor de copia
	Persona(const Persona& p) : nombre(p.nombre), edad(p.edad), cedula(p.cedula) {}

	std::string getNombre() const { return nombre; }
	short int getEdad() const { return edad; }
	std::string getCedula() const { return cedula; }

	void setNombre(std::string n) { nombre = n; }
	void setEdad(short int e) { edad = e; }
	void setCedula(std::string c) { cedula = c; }

private:
	std::string nombre;
	short int edad;
	std::string cedula;
};

#endif
