// source.cpp
// Muestra el uso de archivos
// Utiliza el operador de flujo "<<" para almacenar los datos en el archivo y
// el operador ">>" para recuperarlos
// Llame al programa primero con la funci�n guardar para generar datos en el
// archivo. Utilice los comentarios para leer/guardar en el archivo
// Autor: El Tigre

#include "persona.h"
#include <iostream>
#include <fstream>

#define PERSONAS	3

int GuardarPersonaEnArchivo(Persona*);
int CargarPersonaDeArchivo(Persona*);
void CrearInstancias(Persona*);
void MostrarPersonas(Persona*);

int main() {
	// Creamos un vector de personas. Inicialmente las personas no tienen datos
	// - se instancia al constructor default con datos en blanco
	Persona Per[PERSONAS];

	// CODIGO PARA GUARDAR EN EL ARCHIVO - ELIMINE COMENTARIOS ABAJO PARA CORRER
	// *************************************************************************
	CrearInstancias(Per);
	GuardarPersonaEnArchivo(Per);

	// CODIGO PARA LEER DEL ARCHIVO - ELIMINE COMENTARIOS ABAJO PARA CORRER
	// ********************************************************************   
	//cargarPersonaDeArchivo(Per);
	//mostrarPersonas(Per);

	return 0;
}

// Funci�n que lee los datos de un vector de personas y los almacena en 
// un archivo. Cada persona se almacena en una l�nea separada
// La funci�n recibe como par�metro un puntero al vector de personas
int GuardarPersonaEnArchivo(Persona* ptr) {
	// Instanciamos un objeto de tipo ofstream
	// para guardar los datos en el archivo
	std::ofstream handle;

	// Abrimos el archivo - con la ruta relativa
	// El archivo se abre modo escritura - std::ios::out
	// y en formato de texto
	// NOTA: Si el archivo se abre pierde todos los datos, use std::ios:app
	//       para abrir el archivo y agregar datos a los existentes
	handle.open("persona.txt");

	// Si hay un error al abrir el archivo, retornamos -1 como c�digo de error
	if (!handle.is_open())
		return -1;

	// Para cada persona del vector de personas, leemos los datos 
	// y los almacenamos en el archivo
	for (int i = 0; i < PERSONAS; ++i) {
		handle << ptr[i].getNombre() << " ";
		handle << ptr[i].getEdad() << " ";
		handle << ptr[i].getCedula() << " ";
		handle << std::endl;
	}

	// Cerramos el archivo
	handle.close();

	// Si la funci�n termina con �xito retorna 0
	return 0;
}


// Funci�n que lee los datos de un archivo y los almacena en cada
// objeto de tipo Persona del Vector
// La funci�n recibe como par�metro un puntero al vector de personas
int CargarPersonaDeArchivo(Persona* ptr) {
	// Instanciamos un objeto de tipo ifstream
	// para leer datos del archivo
	std::ifstream handle;

	// Necesitamos variables para recuperar los datos del archivo
	std::string n;
	int e;
	std::string c;

	// Abrimos el archivo - con la ruta relativa
	// El archivo se abre modo lectura - std::ios::in
	// Y en formato de texto
	handle.open("persona.txt");

	// Si hay un error al abrir el archivo, retornamos -1 como c�digo de error
	if (!handle.is_open())
		return -1;

	// Para cada persona del vector de personas, leemos los datos del archivo
	// y los almacenamos en cada instancia
	for (int i = 0; i < PERSONAS; ++i) {
		handle >> n; // Leemos el nombre del archivo
		handle >> e; // Leemos la edad del archivo
		handle >> c; // Leemos la cedula del archivo
		ptr[i].setNombre(n);
		ptr[i].setEdad(e);
		ptr[i].setCedula(c);
	}

	// Cerramos el archivo
	handle.close();

	// Si la funci�n termina con �xito retorna 0
	return 0;
}

void CrearInstancias(Persona* ptr) {
	ptr[0].setNombre("Jose");
	ptr[0].setEdad(37);
	ptr[0].setCedula("12345");

	ptr[1].setNombre("Pablo");
	ptr[1].setEdad(25);
	ptr[1].setCedula("9876543");

	ptr[2].setNombre("Alejandra");
	ptr[2].setEdad(31);
	ptr[2].setCedula("88888");
}

// Recorre un vector de personas dado por el apuntador 'ptr' y muestra la
// informaci�n de cada instancia
void MostrarPersonas(Persona* ptr) {
	for (int i = 0; i < PERSONAS; ++i) {
		std::cout << "Nombre: " << ptr[i].getNombre() << std::endl;
		std::cout << "Edad: " << ptr[i].getEdad() << std::endl;
		std::cout << "Cedula: " << ptr[i].getCedula() << std::endl;
		std::cout << std::endl;
	}
}