// source.cpp
// Programa de prueba para guardar, recuperar y trabajar operaciones con archivos binarios
// Autor: El Tigre

#include "foo.h"
#include <iostream>
#include <fstream>
#include <string>

// Prototipos de funci�n
void GuardarEnArchivo(std::string, const Foo&);
void LeerDeArchivo(std::string, Foo&);
std::streampos LongitudDeArchivo(std::string);

int main() {
	std::string nombre_archivo = "datos.dat";

	// Inicializamos una instancia para guardar en el archivo
	Foo f1(94, 13, 88.65);

	// Guardamos el registro en el archivo binario
	GuardarEnArchivo(nombre_archivo, f1);

	std::cout << "Longitud del archivo (en Bytes): " << LongitudDeArchivo(nombre_archivo);

	// Recuperamos el dato desde el archivo
	Foo f2;
	LeerDeArchivo(nombre_archivo, f2);
	
	return 0;
}

// Utiliza un objeto ofstream para abrir un archivo en binario y almacenar el objeto Foo
void GuardarEnArchivo(std::string nombre, const Foo& obj) {
	std::ofstream handle;
	
	// Se abre el archivo en modo binario, si el archivo existe se agregan los datos al final
	// El puntero "PUT" se posiciona al final del archivo
	handle.open(nombre, std::ios::binary | std::ios::app);

	if (!handle.is_open()) {
		std::cout << "Error al abrir el archivo '" << nombre << "'";
		exit(EXIT_FAILURE);
	}

	// Guardamos los bytes almacenados en la posici�n de memoria del objeto
	// Se almacenan "Foo" Bytes - es decir, el tama�o del objeto Foo
	handle.write((char*)&obj, sizeof(Foo));
	
	handle.close();
}

// Utiliza un objeto ifstream para leer de un archivo y guardarlo en el objeto Foo
void LeerDeArchivo(std::string nombre, Foo& obj) {
	std::ifstream handle;

	// Se abre el archivo en modo binario
	// El puntero "GET" se posiciona al inicio del archivo
	handle.open(nombre, std::ios::binary);

	if (!handle.is_open()) {
		std::cout << "Error al abrir el archivo '" << nombre << "'";
		exit(EXIT_FAILURE);
	}

	// Se leen "Foo" Bytes del archivo y se copian sobre la referencia del objeto
	handle.read((char*)&obj, sizeof(Foo));

	handle.close();
}

// Obtiene el tama�o del archivo
std::streampos LongitudDeArchivo(std::string nombre) {
	std::ifstream handle;
	std::streampos inicio;
	std::streampos fin;

	// Se abre el archivo en modo binario
	// El puntero "GET" se posiciona al final del archivo
	handle.open(nombre, std::ios::binary | std::ios::ate);

	if (!handle.is_open()) {
		std::cout << "Error al abrir el archivo '" << nombre << "'";
		exit(EXIT_FAILURE);
	}

	// Obtenemos el n�mero de Byte al final del archivo
	fin = handle.tellg();

	// Posicionamos el puntero "GET" del archivo al inicio
	handle.seekg(std::ios::beg);

	// Obtenemos el n�mero de Byte al inicio del archivo
	inicio = handle.tellg();

	handle.close();

	return fin - inicio;
}