// foo.h
// Clase de prueba para guardar y recuperar datos en archivos binarios
// Autor: El Tigre

#ifndef FOO_H
#define FOO_H

class Foo {
public:
	// Constructor con par�metros
	// Si se invoca sin par�metros inicializa todos los valores en cero
	Foo(int a = 0, int b = 0, double c = 0.0) : primero{ a }, segundo{ b }, tercero{ c }{}

private:
	int primero;
	int segundo;
	double tercero;
};

#endif