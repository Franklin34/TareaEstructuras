// source.cpp
// Demostraci�n del uso de archivos de texto
// Nota: El archivo de prueba se ubica en directorio principal del proyecto
//       (working directory) - "texto.txt"
// Autor: El tigre

#include <iostream>
#include <fstream>
#include <string>

void ImprimirPalabras(std::ifstream&);
void ImprimirLineas(std::ifstream&);

int main() {
	std::ifstream archivo;

	// Se abre el archivo en modo texto y solo lectura
	// Default para ifstream
	archivo.open("texto.txt");

	// Verificamos que el archivo se haya abierto correctamente
	if (!archivo.is_open()) {
		return -1;
	}

	ImprimirPalabras(archivo);

	// Limpiamos el bit EOF
	archivo.clear();
	// Devolvemos el puntero al inicio del archivo
	archivo.seekg(0, std::ios::beg);

	ImprimirLineas(archivo);

	// Cerramos el archivo
	archivo.close();

	return 0;
}

// Lee cada palabra del archivo (separada por espacio o salto de l�nea \n)
void ImprimirPalabras(std::ifstream& arch) {
	std::string palabra;

	while (arch >> palabra) {
		std::cout << palabra << "\n";
	}
	std::cout << "\n\n\n";
}

// Lee cada l�nea del archivo (usando el separador default - salto de l�nea \n)
void ImprimirLineas(std::ifstream& arch){
	std::string linea;

	while (std::getline(arch, linea)) {
		std::cout << linea << "\n";
	}
}
