// source.cpp
// Demostraci�n del paso de argumentos al programa y creaci�n de archivos de
// texto
// Autor: El Tigre

#include <iostream>
#include <fstream>

int main(int argc, char* argv[]) {
	// Revisamos la cantidad de par�metros al programa. Si no hay suficientes 
	// par�metros el programa termina
	if (argc < 2) {
		std::cout << "Insuficientes argumentos.\n Uso: "
			<< argv[0]
			<< " [parametro 1] [parametro 2] ...\n";
		return -1;
	}

	// Instancia del archivo
	std::ofstream archivo;

	// Se abre el archivo en modo R/W. Si el archivo ya existe se mantiene la
	// informaci�n y se agregan los datos al final  (modo APPEND)
	archivo.open("texto.txt", std::ios::app);

	if (!archivo.is_open()) {
		std::cout << "Error al abrir el archivo";
		return -1;
	}

	// Iteramos sobre los par�metros (argv) y los almacenamos en el archivo
	for (int i = 0; i < argc; i++) {
		archivo << argv[i] << "\n";
	}

	archivo.close();

	return 0;
}