#include "ColaPrioridad.h"
#include <iostream>


int main() {
	ColaPrioridad cola(10);

	cola.Agregar(13);
	cola.Agregar(15);
	cola.Agregar(22);
	cola.Agregar(3);
	cola.Agregar(11);
	cola.Agregar(18);
	cola.Agregar(40);
	cola.Agregar(8);
	cola.Agregar(23);
	cola.Agregar(34);
	cola.Agregar(4);

	std::cout << cola.ExtraerMax() << "\n";
	std::cout << cola.ExtraerMax() << "\n";
	std::cout << cola.ExtraerMax() << "\n";
	std::cout << cola.ExtraerMax() << "\n";
	

	return 0;
}