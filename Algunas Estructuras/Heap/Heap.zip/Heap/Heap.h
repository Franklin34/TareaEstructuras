// heap.h
// Autor: El Tigre
// Descripci�n: Declaraci�n de la Clase Heap - para el manejo de MAX o MIN Heaps

#ifndef HEAP_H
#define HEAP_H

#define TAM_DEFAULT	10

class Heap {
public:
	// Constructor default
	Heap();
	// Inicializa vector de tama�o N - todos los valores en cero
	Heap(int);
	// Constructor de copia
	Heap(const Heap&);
	//Destructor
	~Heap();

	// Retorna la posici�n del nodo padre para la posicion dada
	int GetPadre(const int) const;
	// Retorna la posici�n del hijo izquierdo
	int GetHijoIzquierdo(const int) const;
	// Retorna la posici�n del hijo derecho
	int GetHijoDerecho(const int) const;
	// Obtiene el valor MAX del Heap
	int GetMax() const;
	// Obtiene el valor MAX del heap y lo elimina del Heap
	int BorrarMax();
	// Inserta un nuevo valor en el Heap
	void Insertar(const int);
	// Elimina el Heap completamente
	void EliminarHeap();
private:
	int* v;
	int capacidad;
	int tam;

	// Asegura que el Heap cumpla con las propiedades necesarias
	void Heapify(int);
	// Extiende el tama�o del Heap
	void Extender();
};

#endif
