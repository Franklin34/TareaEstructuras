// heap.ccp
// Autor: El Tigre
// Descripci�n: Definici�n de la clase Heap

#include "heap.h"

// Constructor Default. Crea un Heap de TAM_DEFAULT posiciones inicializados en cero
Heap::Heap() : v{ nullptr }, capacidad{ TAM_DEFAULT }, tam{ 0 } {
	v = new int[capacidad];

	for (int i = 0; i < TAM_DEFAULT; ++i)
		v[i] = 0;
}

// Inicializa un Heap de tama�o t - todos los valores en cero
Heap::Heap(int t) : v{ nullptr }, capacidad{ t }, tam{ 0 } {
	v = new int[capacidad];

	for (int i = 0; i < capacidad; ++i)
		v[i] = 0;
}

// Constructor de copia
Heap::Heap(const Heap& val) {
	this->capacidad = val.capacidad;
	this->tam = val.tam;

	this->v = new int[capacidad];

	for (int i = 0; i < capacidad; ++i)
		this->v[i] = val.v[i];
}

//Destructor
Heap::~Heap() {
	EliminarHeap();
}

// Retorna la posici�n del nodo padre para la posicion dada
int Heap::GetPadre(const int pos) const {
	if (pos < 0 || pos >= tam)
		return -1;
	return (pos - 1) / 2;
}

// Retorna la posici�n del hijo izquierdo
int Heap::GetHijoIzquierdo(const int pos) const {
	int izq = pos * 2 + 1;
	if (izq >= tam)
		return -1;
	return izq;
}

// Retorna la posici�n del hijo derecho
int Heap::GetHijoDerecho(const int pos) const {
	int der = pos * 2 + 2;
	if (der >= tam)
		return -1;
	return der;
}

// Obtiene el valor MAX del Heap
int Heap::GetMax() const {
	if (tam == 0)
		return -1;
	return v[0];
}

// Obtiene el valor MAX del heBap y lo elimina del Heap
int Heap::BorrarMax() {
	if (tam == 0)
		return -1;

	// Obtenemos el valor MAX
	int valor = v[0];
	
	// Reemplazamos el MAX con el �ltimo elemento y 
	// reducimos el tama�o del heap
	v[0] = v[tam - 1];
	--tam;

	// Verificamos que se cumpla la propiedad del Heap
	Heapify(0);
	
	// Retornamos el valor MAX
	return valor;
}

// Inserta un nuevo valor en el Heap
void Heap::Insertar(const int valor) {
	int pos;
	
	// Si sobrepasamos la capacidad del vector, incrementamos su tama�o
	if (tam == capacidad)
		Extender();
	
	// Obtenemos la �ltima posici�n del vector
	pos = tam++;

	// Procedimiento de Heapifying (desde el �ltimo nivel hasta la ra�z)
	while (pos > 0 && valor > v[(pos - 1) / 2]) {
		v[pos] = v[(pos - 1) / 2];
		pos = (pos - 1) / 2;
	}
	v[pos] = valor;
}

// Elimina el Heap completamente
void Heap::EliminarHeap() {
	delete v;
	v = nullptr;
	capacidad = 0;
	tam = 0;
}

// Asegura que el Heap cumpla con las propiedades necesarias
void Heap::Heapify(int pos) {
	int max;
	
	// Obtenemos los hijos izquierdo y derecho a partir de la posici�n dada
	int izq = GetHijoIzquierdo(pos);
	int der = GetHijoDerecho(pos);

	// Calculamos el elemento m�ximo para la posici�n
	if (izq != -1 && v[izq] > v[pos])
		max = izq;
	else
		max = pos;
	if (der != -1 && v[der] > v[max])
		max = der;

	// Si el elemento mayor del heap es diferente al indicado
	// en la posici�n, intercambiamos
	if (max != pos) {
		int tmp = v[pos];
		v[pos] = v[max];
		v[max] = tmp;
		Heapify(max);
	}
}

// Extiende el tama�o del Heap
void Heap::Extender() {
	int* tmp = v;
	v = new int[capacidad + 10];

	for (int i = 0; i < capacidad; ++i)
		v[i] = tmp[i];

	capacidad += 10;
	delete tmp;
}