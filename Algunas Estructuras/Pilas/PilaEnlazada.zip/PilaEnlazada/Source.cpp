#include "Stack.h"

int main() {
	Stack pila;

	std::cout << "Push -> 7" << "\n";
	pila.push(7);
	std::cout << "Push -> 22" << "\n";
	pila.push(22);
	std::cout << "Push -> 26" << "\n";
	pila.push(26);

	std::cout << "\n";
	std::cout << "Mostrando el tope:" << pila.peek() << "\n";

	std::cout << "\n";
	std::cout << "Pop -> " << pila.pop() << "\n";
	std::cout << "Pop -> " << pila.pop() << "\n";
	std::cout << "Pop -> " << pila.pop() << "\n";

	std::cout << "\n" << "Cuando la pila esta vacia: ";
	std::cout << "Pop -> " << pila.pop() << "\n";

	return 0;
}