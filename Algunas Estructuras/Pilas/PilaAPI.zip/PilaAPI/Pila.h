// Pila.h
// Autor: El Tigre
// Descripci�n: Definici�n de una pila (Stack)

#ifndef PILA_H
#define PILA_H

#include <iostream>
#include <cstddef>

template<class T> class Pila {
private:
	struct Nodo {
		T valor;
		Nodo* next;
		Nodo(T val, Nodo* sig = nullptr) : valor{ val }, next{ sig } {}
	};

	// Apuntadores al inicio y fin de la lista
	Nodo* top;
	
	void Inicializar() { top = nullptr; }

public:
	// Interfaz de la Pila

	// Constructores
	// Default
	Pila() { Inicializar(); }

	// Destructor
	~Pila() { BorrarPila(); }

	// Operaci�n pus() - Inserta un elemento en la pila
	void push(const T& val) {
		Nodo* nuevo;

		try {
			nuevo = new Nodo(val, top);
		}
		catch (std::bad_alloc exception) {
			return;
		}

		if (top == nullptr)
			top = nuevo;
		else
			top = nuevo;
	}

	// Operaci�n pop() - No verifica si no existen elementos
	T pop() {
		Nodo* tmp = top;
		top = top->next;
		T val = tmp->valor;
		delete tmp;
		return val;
	}

	// Borra completamente la pila
	void BorrarPila() {
		Nodo* tmp;
		while (top != nullptr) {
			tmp = top;
			top = top->next;
			delete tmp;
		}
	}
};

#endif
