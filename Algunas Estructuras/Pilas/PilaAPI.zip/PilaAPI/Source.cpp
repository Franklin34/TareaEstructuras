#include <iostream>
#include "Pila.h"

int main() {
	Pila<int> p;

	p.push(45);
	p.push(60);
	p.push(35);

	std::cout << p.pop() << " ";
	std::cout << p.pop() << " ";
	std::cout << p.pop() << " ";

	return 0;
}