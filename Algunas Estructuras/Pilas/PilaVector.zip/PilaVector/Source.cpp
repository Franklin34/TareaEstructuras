#include "Stack.h"
#include <iostream>

using std::cout;
using std::endl;

int main() {
	Stack pila;

	cout << "Push -> 7" << endl;
	pila.push(7);
	cout << "Push -> 22" << endl;
	pila.push(22);
	cout << "Push -> 26" << endl;
	pila.push(26);
	
	cout << endl;
	cout << "Mostrando el tope:" << pila.peek() << endl;

	cout << endl;
	cout << "Pop -> " << pila.pop() << endl;
	cout << "Pop -> " << pila.pop() << endl;
	cout << "Pop -> " << pila.pop() << endl;

	return 0;
}